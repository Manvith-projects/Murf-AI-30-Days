# Flask App

A simple Flask web application with virtual environment setup.

## Setup Instructions

### 1. Activate Virtual Environment
```bash
# On Windows PowerShell
.\flask_env\Scripts\Activate.ps1

# On Windows Command Prompt
flask_env\Scripts\activate.bat

# On macOS/Linux
source flask_env/bin/activate
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Application
```bash
python app.py
```

The application will be available at: http://127.0.0.1:5000

## Features

- ✅ Virtual environment setup
- ✅ Flask web framework
- ✅ Template rendering with Jinja2
- ✅ RESTful API endpoints
- ✅ Bootstrap responsive design
- ✅ AJAX functionality

## Project Structure

```
.
├── flask_env/              # Virtual environment
├── templates/              # HTML templates
│   ├── index.html         # Home page
│   └── about.html         # About page
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
└── README.md             # This file
```

## API Endpoints

- `GET /` - Home page
- `GET /about` - About page
- `GET /api/hello` - Returns a hello message
- `POST /api/hello` - Returns a personalized hello message

## Development

The app runs in debug mode by default, which means:
- Auto-reload on file changes
- Detailed error messages
- Debug toolbar available

To run in production mode, set `debug=False` in `app.py`.
