from flask import Flask, request, jsonify, render_template, render_template_string
from dotenv import load_dotenv
import os
import requests
from werkzeug.utils import secure_filename
import assemblyai as aai
import io


load_dotenv()

app = Flask(__name__)

MURF_API_KEY = os.getenv("MURF_API_KEY")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api")
def api():
    return render_template("api.html")

@app.route("/generate-audio", methods=["POST"])
def generate_audio():

    text = request.json.get("text") if request.is_json else request.form.get("text")

    if not text:
        return jsonify({"error": "No text provided"}), 400

    headers = {
        "api-key": MURF_API_KEY
    }

    payload = {
        "text": text,
        "voiceId": "en-US-natalie",  
        "pronunciationDictionary": {
            "2010": {
                "pronunciation": "two thousand and ten",
                "type": "SAY_AS"
            },
            "live": {
                "pronunciation": "laɪv",
                "type": "IPA"
            }
        }
    }

    try:
        response = requests.post("https://api.murf.ai/v1/speech/generate", headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()

        audio_url = result.get("audioFile")
        if not audio_url:
            return jsonify({"error": "No audio URL found in response"}), 500

        
        if not request.is_json:
            return render_template("audio.html", audio_url=audio_url)

        return jsonify({"audio_url": audio_url})

    except requests.exceptions.RequestException as e:
        return jsonify({"error": str(e)}), 500



UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/upload_audio', methods=['POST'])
def upload_audio():
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided'}), 400

    audio = request.files['audio']
    filename = secure_filename(audio.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    try:
        audio.save(filepath)
        size = os.path.getsize(filepath)
        return jsonify({
            'filename': filename,
            'content_type': audio.content_type,
            'size': size
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


aai.settings.api_key =  os.getenv("ASSEMBLYAI_API_KEY")

@app.route('/transcribe/file', methods=['POST'])
def transcribe_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    
    # Read file data directly without saving
    audio_data = io.BytesIO(file.read())

    # Use AssemblyAI SDK to transcribe
    transcriber = aai.Transcriber()
    transcript = transcriber.transcribe(audio_data)

    return jsonify({'transcript': transcript.text})

if __name__ == "__main__":
    app.run(debug=True)
